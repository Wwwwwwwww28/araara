import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from Service.WindowBuilders.MainWindowBuilder import MainWindowBuilder


class Main:
    def __init__(self):
        MainWindowBuilder()


if __name__ == '__main__':
    main = Main()
    Gtk.main()
