import subprocess

import virtualbox
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from Service.WindowBuilders.MainWindowEventHandler import EventHandler


class MainWindowBuilder:
    def __init__(self):
        self.builder = Gtk.Builder()
        self.builder.add_from_file("res/Ar.glade")

        self.local_vm_tv = self.builder.get_object("local_tv_vms")

        self.fill_tv_vms()

        self.builder.connect_signals(EventHandler())
        self.main_window = self.builder.get_object("main")
        self.main_window.show()

    def fill_tv_vms(self):
        list_store = Gtk.ListStore(int, str, bool, bool, str)

        vm = virtualbox.VirtualBox()

        i = 0
        while i < len(vm.machines):
            ip = subprocess.getoutput("VBoxManage guestproperty enumerate " + vm.machines[i].id_p + " | grep IP")

            if vm.machines[i].state == 1:
                state = False
            else:
                state = True

            list_store.append([i + 1, vm.machines[i].name, vm.machines[i].autostart_enabled, state, ip])

            i += 1

        text_renderer = Gtk.CellRendererText()
        bool_renderer = Gtk.CellRendererToggle()

        col1 = Gtk.TreeViewColumn(title="№, п/п", cell_renderer=text_renderer, text=0)
        col2 = Gtk.TreeViewColumn(title="Виртуальная машина", cell_renderer=text_renderer, text=1)
        col3 = Gtk.TreeViewColumn(title="Автозапуск", cell_renderer=bool_renderer, active=2)
        col4 = Gtk.TreeViewColumn(title="Статус", cell_renderer=bool_renderer, active=3)
        col5 = Gtk.TreeViewColumn(title="IP-адрес", cell_renderer=text_renderer, text=4)

        self.local_vm_tv.append_column(col1)
        self.local_vm_tv.append_column(col2)
        self.local_vm_tv.append_column(col3)
        self.local_vm_tv.append_column(col4)
        self.local_vm_tv.append_column(col5)

        self.local_vm_tv.set_model(list_store)
