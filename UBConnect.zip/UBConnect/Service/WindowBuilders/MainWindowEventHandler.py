import virtualbox
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


class EventHandler:

    def __init__(self):
        self.selected_vm = None
        self.vm = virtualbox.VirtualBox()
        self.session = None
        self.machine = None

    def on_destroy(self, widget):
        Gtk.main_quit()

    def on_selection_changed(self, widget):
        model, treeiter = widget.get_selected()

        if treeiter is not None:

            temp = model.get_path(treeiter)
            row_num = int(temp.to_string())

            hashes = []

            for item in self.vm.machines:
                hashes.append(item.id_p)

            self.selected_vm = hashes[row_num]

    def start_vm(self, widget):
        self.machine = self.vm.find_machine(self.selected_vm)
        self.session = virtualbox.Session()

        proc = self.machine.launch_vm_process(self.session, "headless", [])
        proc.wait_for_completion()

    def turn_off_vm(self, widget):
        self.session.console.power_button()

    def reboot_vm(self, widget):
        self.session.console.reset()
