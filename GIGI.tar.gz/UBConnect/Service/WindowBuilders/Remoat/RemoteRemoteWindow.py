import gi


gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


class RemoteRemoteWindow:
    def __init__(self):
        self.builder = Gtk.Builder()
        self.builder.add_from_file("res/Ar.glade")
        self.second_win = self.builder.get_object("remote2")
        self.builder.connect_signals(EventHandler(self))
        self.second_win.show()

class EventHandler:

    def __init__(self, context):
        self.context = context

    def close_remote_remote(self, test):
        self.context.second_win.destroy()
        print("XYI")

if __name__ == '__main__':
    main = RemoteRemoteWindow()
    Gtk.main()
