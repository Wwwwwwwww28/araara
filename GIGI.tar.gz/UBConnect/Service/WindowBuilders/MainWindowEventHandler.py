import gtk
import virtualbox
import gi

from Service.WindowBuilders import MainWindowBuilder
from Service.WindowBuilders.ConfigVmWindow import ConfigVmWindow
from Service.WindowBuilders.Local.LocalRdpWindow import LocalRdpWindow
from Service.WindowBuilders.Local.LocalRemoteWindow import LocalRemoteWindow
from Service.WindowBuilders.Local.LocalVrdpWindow import LocalVrdpWindow
from Service.WindowBuilders.Remoat.RemoatRdpWindow import RemoteRdpWindow
from Service.WindowBuilders.Remoat.RemoatVrdpWindow import RemoteVrdpWindow
from Service.WindowBuilders.Remoat.RemoteRemoteWindow import RemoteRemoteWindow

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


class EventHandler:

    def __init__(self):
        self.selected_vm = None
        self.vm = virtualbox.VirtualBox()
        self.session = None
        self.machine = None

    def on_destroy(self, widget):
        Gtk.main_quit()

    def on_selection_changed(self, widget):
        model, treeiter = widget.get_selected()

        if treeiter is not None:

            temp = model.get_path(treeiter)
            row_num = int(temp.to_string())

            hashes = []

            for item in self.vm.machines:
                hashes.append(item.id_p)

            self.selected_vm = hashes[row_num]

    def start_vm(self, widget):
        self.machine = self.vm.find_machine(self.selected_vm)
        self.session = virtualbox.Session()

        proc = self.machine.launch_vm_process(self.session, "headless", [])
        proc.wait_for_completion()

    def turn_off_vm(self, widget):
        self.session.console.power_button()

    def reboot_vm(self, widget):
        self.session.console.reset()

    def local_btn_vrdp_clicked_cb(self, widget):
        LocalVrdpWindow()

    def local_btn_rdp_clicked_cb(self, widget):
        LocalRdpWindow()

    def local_btn_remoteapp_clicked_cb(self, widget):
        LocalRemoteWindow()

    def remote_btn_vrdp_clicked_cb(self, widget):
        RemoteVrdpWindow()

    def remote_btn_rdp_clicked_cb(self, widget):
        RemoteRdpWindow()

    def remote_btn_remoteapp_clicked_cb(self, widget):
        RemoteRemoteWindow()

    def btn_vbox_config_clicked_cb(self, widget):
        asd = ConfigVmWindow(self.mashine)
        ConfigVmWindow()

    def on_selection_changed(self, widget):
        i = 0
        model, iter = widget.get_selected()
        data = model.get_value(iter, 0)
        self.mashine = virtualbox.VirtualBox().machines[data-1]
        print(virtualbox.VirtualBox().machines[data - 1])



